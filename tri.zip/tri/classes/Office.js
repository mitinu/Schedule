class Office {
    id = ""
    day = [true, true, true, true, true, true]
    constructor(name) {
        this.id = name
    }
}
module.exports = Office;
