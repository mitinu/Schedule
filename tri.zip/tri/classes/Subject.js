class Subject {
    name = ""
    id = -1
    constructor(name, id) {
        this.name = name
        this.id = id
    }
}
module.exports = Subject;